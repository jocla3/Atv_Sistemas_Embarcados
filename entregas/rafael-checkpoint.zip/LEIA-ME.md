# Entrega de Rafael

Conta GitHub esperada — `rafaelcf29`. Área — Interface e documentação.

Revise os arquivos e execute os testes da sua área. As instruções completas estão em `docs/CONTRIBUICOES.md`, no repositório principal.

Primeiro, abra https://github.com/jocla3/Atv_Sistemas_Embarcados e clique em Fork para criar uma cópia na conta `rafaelcf29`.

Clone o repositório usando suas próprias credenciais:

```sh
git clone https://github.com/rafaelcf29/Atv_Sistemas_Embarcados.git
cd Atv_Sistemas_Embarcados
git switch -c checkpoint/rafael
git config user.name
git config user.email
```

Confira se nome e e-mail são seus. Caso necessário, configure-os localmente com `git config user.name "Seu nome completo"` e `git config user.email "Seu e-mail verificado no GitHub"`. Você também pode usar o endereço noreply informado nas configurações de e-mail da sua conta GitHub.

Copie o **conteúdo** da pasta `arquivos/` deste pacote para a raiz do clone. Preserve os caminhos. Confira `git status` e `git diff` e faça os dois commits abaixo.

## Commit 1

```sh
git add applications/frontend/index.html applications/frontend/style.css applications/frontend/app.js applications/frontend/README.md
git diff --cached --stat
git commit -m "feat(interface): adicionar prototipo interativo de iluminacao"
```

## Commit 2

```sh
git add docs/testes/interface.md docs/Relatorio_CheckPoint_Grupo_3.docx
git diff --cached --stat
git commit -m "docs(interface): adicionar roteiro de testes e relatorio do grupo"
```

## Publicação

```sh
git push -u origin checkpoint/rafael
```

Abra um Pull Request para `jocla3/Atv_Sistemas_Embarcados`, branch `main`, a partir da branch `checkpoint/rafael` da sua conta. Informe os testes realizados e as pendências. Combine com João a integração usando **Create a merge commit**.

Não é necessário fazer push de todos os arquivos do pacote completo. Os seus dois commits incluem somente os caminhos listados acima.
