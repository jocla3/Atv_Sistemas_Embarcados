# Testes do protótipo visual

Responsável — Rafael (@rafaelcf29).

| Ação | Resultado esperado | Registro |
| --- | --- | --- |
| Abrir index.html | Aviso de simulação e valor inicial 2200 | A registrar |
| Automático e leitura 1000 | Luz simulada ligada | A registrar |
| Aumentar para 1600 | Mantém ligada | A registrar |
| Aumentar para 2000 | Desliga | A registrar |
| Forçar desligada com leitura 1000 | Mantém desligada | A registrar |
| Forçar ligada com leitura 3000 | Mantém ligada | A registrar |
| Voltar ao automático | Retoma a regra do sensor | A registrar |
| Alterar mais de 20 vezes | Mantém as últimas 20 linhas | A registrar |
| Recarregar | Reinicia a simulação e o histórico | A registrar |

Confira também navegação por teclado e largura de tela pequena. Os testes desta interface usam dados simulados. A confirmação de estados reais e a integração MQTT serão verificadas após implementação.
