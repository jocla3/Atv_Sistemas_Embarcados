# Entrega de Caio

Conta GitHub esperada — `Caiosenas2101`. Área — Circuito e testes de hardware.

Revise os arquivos e execute os testes da sua área. As instruções completas estão em `docs/CONTRIBUICOES.md`, no repositório principal.

Primeiro, abra https://github.com/jocla3/Atv_Sistemas_Embarcados e clique em Fork para criar uma cópia na conta `Caiosenas2101`.

Clone o repositório usando suas próprias credenciais:

```sh
git clone https://github.com/Caiosenas2101/Atv_Sistemas_Embarcados.git
cd Atv_Sistemas_Embarcados
git switch -c checkpoint/caio
git config user.name
git config user.email
```

Confira se nome e e-mail são seus. Caso necessário, configure-os localmente com `git config user.name "Seu nome completo"` e `git config user.email "Seu e-mail verificado no GitHub"`. Você também pode usar o endereço noreply informado nas configurações de e-mail da sua conta GitHub.

Copie o **conteúdo** da pasta `arquivos/` deste pacote para a raiz do clone. Preserve os caminhos. Confira `git status` e `git diff` e faça os dois commits abaixo.

## Commit 1

```sh
git add schematics/circuito.txt schematics/circuito.svg schematics/README.md
git diff --cached --stat
git commit -m "docs(hardware): adicionar circuito e guia de montagem"
```

## Commit 2

```sh
git add docs/ARQUITETURA.md docs/testes/hardware.md
git diff --cached --stat
git commit -m "docs(hardware): descrever arquitetura e verificacao da montagem"
```

## Publicação

```sh
git push -u origin checkpoint/caio
```

Abra um Pull Request para `jocla3/Atv_Sistemas_Embarcados`, branch `main`, a partir da branch `checkpoint/caio` da sua conta. Informe os testes realizados e as pendências. Combine com João a integração usando **Create a merge commit**.

Não é necessário fazer push de todos os arquivos do pacote completo. Os seus dois commits incluem somente os caminhos listados acima.
