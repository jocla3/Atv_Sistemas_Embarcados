# Testes da comunicação

Responsável — Raul (@raulvnc).

| Teste | Resultado esperado | Situação |
| --- | --- | --- |
| Validar Compose | Configuração aceita sem erros | Verificado na preparação |
| Iniciar serviços | Mosquitto e Node-RED ativos | Registrar execução |
| Publicação manual | JSON recebido pelo assinante | Registrar execução |
| Importar fluxo | Telemetria aparece no Debug | Registrar execução |
| Enviar comando | Assinante recebe automatico/ligada/desligada | Registrar execução |
| Integrar ESP32 | Telemetria vem da placa e comando altera saída | Pendente de implementação |
| Reconectar placa | Recupera conexão sem repetir comando antigo | Pendente de implementação |

Use os comandos do README de `applications/`. Para testar comandos, assine `grupo3/iluminacao/comando` e use um botão Inject no Node-RED. Registre data, responsável, mensagem, resultado e logs. Mensagens manuais devem ser identificadas como teste.
