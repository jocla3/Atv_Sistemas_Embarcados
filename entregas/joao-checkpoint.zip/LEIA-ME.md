# Entrega de Joao

Conta GitHub esperada — `jocla3`. Área — Firmware e integração.

Revise os arquivos e execute os testes da sua área. As instruções completas estão em `docs/CONTRIBUICOES.md`, no repositório principal.

Clone o repositório usando suas próprias credenciais:

```sh
git clone https://github.com/jocla3/Atv_Sistemas_Embarcados.git
cd Atv_Sistemas_Embarcados
git switch -c checkpoint/joao
git config user.name
git config user.email
```

Confira se nome e e-mail são seus. Caso necessário, configure-os localmente com `git config user.name "Seu nome completo"` e `git config user.email "Seu e-mail verificado no GitHub"`. Você também pode usar o endereço noreply informado nas configurações de e-mail da sua conta GitHub.

Copie o **conteúdo** da pasta `arquivos/` deste pacote para a raiz do clone. Preserve os caminhos. Confira `git status` e `git diff` e faça os dois commits abaixo.

## Commit 1

```sh
git add esp32-esp8266/iluminacao/iluminacao.ino esp32-esp8266/README.md
git diff --cached --stat
git commit -m "feat(firmware): adicionar automacao local com LDR e LED"
```

## Commit 2

```sh
git add esp32-esp8266/testes/Arduino.h esp32-esp8266/testes/teste_logica.cpp docs/testes/firmware.md
git diff --cached --stat
git commit -m "test(firmware): verificar limites e documentar testes na placa"
```

## Publicação

```sh
git push -u origin checkpoint/joao
```

Abra um Pull Request para `jocla3/Atv_Sistemas_Embarcados`, branch `main`, a partir da branch `checkpoint/joao` da sua conta. Informe os testes realizados e as pendências. Combine com João a integração usando **Create a merge commit**.

Não é necessário fazer push de todos os arquivos do pacote completo. Os seus dois commits incluem somente os caminhos listados acima.
